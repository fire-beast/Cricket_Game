<?php
session_start();
// Initialize scores
if (!isset($_SESSION['user_score'])) {
    $_SESSION['user_score'] = 0;
    $_SESSION['computer_score'] = 0;
    $_SESSION['balls'] = 0;
    $_SESSION['batting'] = true; // Start with the user batting
}

// Function to simulate computer's run selection
function selectRuns() {
    $runs = [1, 2, 3, 4, 6];
    return $runs[array_rand($runs)]; // Randomly select runs
}

// Handle user input and game logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_SESSION['batting']) {
        // User batting phase
        if (isset($_POST['user_run'])) {
            $user_run = intval($_POST['user_run']);
            $computer_run = selectRuns();
            // Check if the batsman is out
            if ($user_run === $computer_run) {
                echo "<h2 class='out'>Batsman is out!</h2>";
                $_SESSION['balls'] = 6; // End batting phase
            } else {
                $_SESSION['user_score'] += $user_run;
                $_SESSION['balls']++;
            }
            // Check if the batting phase is over
            if ($_SESSION['balls'] >= 6) {
                echo "<h2 class='phase-end'>End of Batting Phase!</h2>";
                echo "<p>User Score: " . $_SESSION['user_score'] . "</p>";
                $_SESSION['balls'] = 0; // Reset for bowling phase
                $_SESSION['batting'] = false; // Switch to computer batting phase
            }
        }
    } else {
        // Computer batting phase
        echo "<h2 class='phase'>Bowling Phase!</h2>";
        $computer_run = selectRuns();

        if (isset($_POST['user_run_bowler'])) {
            $user_run = intval($_POST['user_run_bowler']); // User's run selection for bowling

            // Check if the computer is out
            if ($computer_run === $user_run) {
                echo "<h2 class='out'>Computer is out!</h2>";
                echo "<h2 class='game-over'>Game Over!</h2>";
                echo "<p>User Score: " . $_SESSION['user_score'] . "</p>";
                echo "<p>Computer Score: " . $_SESSION['computer_score'] . "</p>";
                echo "<h2 class='winner'>Human Wins!</h2>";

                // Reset the game
                session_destroy();
                echo '<a href="play.php" class="play-again">Play Again</a>';
                exit;
            } else {
                $_SESSION['computer_score'] += $computer_run;
                echo "<p>Computer scored: " . $computer_run . "</p>";
            }

            $_SESSION['balls']++;
            // Check if the computer has exceeded the user's score
            if ($_SESSION['computer_score'] > $_SESSION['user_score']) {
                echo "<h2 class='game-over'>Game Over!</h2>";
                echo "<p>User Score: " . $_SESSION['user_score'] . "</p>";
                echo "<p>Computer Score: " . $_SESSION['computer_score'] . "</p>";
                echo "<h2 class='winner'>Computer Wins!</h2>";
                // Reset the game
                session_destroy();
                echo '<a href="play.php" class="play-again">Play Again</a>';
                exit;
            }
        }
        // Check if the computer's batting phase is over
        if ($_SESSION['balls'] >= 6) {
            // Determine the winner based on scores
            $winner = $_SESSION['user_score'] > $_SESSION['computer_score'] ? 'Human Wins!' : 'Computer Wins!';
            echo "<h2 class='game-over'>Game Over!</h2>";
            echo "<p>User Score: " . $_SESSION['user_score'] . "</p>";
            echo "<p>Computer Score: " . $_SESSION['computer_score'] . "</p>";
            echo "<h2 class='winner'>$winner</h2>";
            // Reset the game
            session_destroy();
            echo '<a href="play.php" class="play-again">Play Again</a>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Over Cricket</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Super Over Cricket</h1>
        <?php if ($_SESSION['batting']): ?>
            <form method="POST" action="play.php" class="run-form">
                <label>Select your runs (Batsman): </label>
                <input type="number" name="user_run" min="1" max="6" required>
                <input type="submit" value="Submit Run">
            </form>
        <?php else: ?>
            <form method="POST" action="play.php" class="run-form">
                <label>Select your runs (Bowler): </label>
                <input type="number" name="user_run_bowler" min="1" max="6" required>
                <input type="submit" value="Submit Run">
            </form>
        <?php endif; ?>
    </div>
</body>
</html>